/* Generated automatically. */
static const char configuration_arguments[] = "../gcc-4.8.1/configure --enable-fixed-point --enable-languages=c,c++ --prefix=/Users/jenkins/jenkins/workspace/toolchain-avr-3.4.3-mac32/objdir --enable-long-long --disable-nls --disable-checking --disable-libssp --disable-libada --disable-shared --with-avrlibc=yes --with-dwarf2 --disable-doc --target=avr";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
